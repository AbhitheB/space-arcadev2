import pygame
import sys
import random
import math
import asyncio  # Built-in web loop engine

# --- INITIALIZATION ---
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Abhi's Advanced Starfighter 1995")
clock = pygame.time.Clock()

# --- STYLED COLORS ---
BG_COLOR = (10, 10, 25)
WHITE = (255, 255, 255)
GLOW_GREEN = (0, 255, 150)
GLOW_PINK = (255, 50, 120)
GLOW_YELLOW = (255, 220, 50)
LASER_BLUE = (0, 200, 255)
PURPLE_EVIL = (180, 50, 255)

# --- GAME STATE ---
game_state = "MENU" 
current_level = 1
score = 0
menu_angle = 0

# --- SHIP HANGAR CONFIG ---
ships = {
    0: {
        "name": "PHOENIX V1", 
        "color": GLOW_GREEN, 
        "shot": "TRIPLE", 
        "model_type": "ARROW",
        "drones": False,
        "desc": "Light interceptor. Wide 3-way assault fire spread."
    },
    1: {
        "name": "VANGUARD X", 
        "color": GLOW_PINK, 
        "shot": "SPREAD", 
        "model_type": "TRIDENT",
        "drones": False,
        "desc": "Tactical wide-wing. Heavy 5-way horizontal wall spray."
    },
    2: {
        "name": "TITAN HEAVY", 
        "color": GLOW_YELLOW, 
        "shot": "CROSS", 
        "model_type": "CRUISER",
        "drones": True,
        "desc": "Dreadnought class. Deploys 2 combat drones + 4-way cross laser."
    }
}
selected_ship = 0

# --- GAME OBJECT MANAGERS ---
player_x, player_y = 400, 500
player_speed = 7

bullets = []  
enemies = []  

# Starfield background
stars = []
for _ in range(60):
    stars.append({
        "x": random.randint(0, WIDTH),
        "y": random.randint(0, HEIGHT),
        "speed": random.uniform(1, 4),
        "size": random.randint(1, 3)
    })

# --- 3D ENGINE MATH FOR UNIQUE HANGAR SHIPS ---
def project_3d(x, y, z, angle):
    rad = math.radians(angle)
    rx = x * math.cos(rad) - z * math.sin(rad)
    rz = x * math.sin(rad) + z * math.cos(rad)
    distance = 5
    scale = 230
    screen_x = int((rx * scale) / (rz + distance) + WIDTH // 2)
    screen_y = int((y * scale) / (rz + distance) + HEIGHT // 2 - 50)
    return screen_x, screen_y

def draw_3d_wireframe_ship(angle, ship_config):
    model_type = ship_config["model_type"]
    color = ship_config["color"]
    
    nodes = []
    edges = []
    
    if model_type == "ARROW":
        nodes = [(0, -0.4, 1.3), (-0.7, 0, -0.8), (0.7, 0, -0.8), (0, 0.3, -0.3), (0, 0, -1.0)]
        edges = [(0,1), (1,4), (4,2), (2,0), (0,3), (3,1), (3,2), (3,4)]
        
    elif model_type == "TRIDENT":
        nodes = [(0, -0.2, 0.8), (-1.0, 0, -0.5), (1.0, 0, -0.5), (-0.5, 0, 0.8), (0.5, 0, 0.8), (0, 0, -0.8)]
        edges = [(0,3), (0,4), (3,1), (4,2), (1,5), (2,5), (5,0)]
        
    elif model_type == "CRUISER":
        nodes = [
            (-0.4, -0.3, 1.0), (0.4, -0.3, 1.0), (-0.5, 0.3, -1.0), (0.5, 0.3, -1.0),
            (-1.4, 0, 0), (1.4, 0, 0)
        ]
        edges = [(0,1), (1,3), (3,2), (2,0), (0,2), (1,3)]
    
    points = [project_3d(n[0], n[1], n[2], angle) for n in nodes]
    for edge in edges:
        pygame.draw.line(screen, color, points[edge[0]], points[edge[1]], 2)
        
    if model_type == "CRUISER":
        if len(points) >= 6:
            pygame.draw.circle(screen, WHITE, points[4], 5)
            pygame.draw.circle(screen, WHITE, points[5], 5)

# --- LASER FIRE ENGINE ---
def fire_laser():
    shot_type = ships[selected_ship]["shot"]
    has_drones = ships[selected_ship]["drones"]
    
    if shot_type == "TRIPLE":
        bullets.append([player_x, player_y - 15, 0, -12])
        bullets.append([player_x, player_y - 15, -4, -11])
        bullets.append([player_x, player_y - 15, 3, -11])
    elif shot_type == "SPREAD":
        for dx in [-7, -3.5, 0, 3.5, 7]:
            bullets.append([player_x, player_y - 15, dx, -10])
    elif shot_type == "CROSS":
        bullets.append([player_x, player_y - 15, 0, -12])
        bullets.append([player_x, player_y + 15, 0, 12])
        bullets.append([player_x - 15, player_y, -12, 0])
        bullets.append([player_x + 15, player_y, 12, 0])
        
    if has_drones:
        bullets.append([player_x - 40, player_y, 0, -14]) 
        bullets.append([player_x + 40, player_y, 0, -14]) 

def spawn_enemies():
    global enemies
    enemies.clear()
    count = 4 + current_level * 2
    
    for i in range(count):
        max_hp = 1 + (current_level // 2)
        if i % 3 == 0:
            bot_type = "STALKER"
            bot_color = PURPLE_EVIL
            speed = random.uniform(1.2, 2.0 + (current_level * 0.15))
        else:
            bot_type = "STANDARD"
            bot_color = GLOW_PINK
            speed = random.uniform(1.5, 3.0 + (current_level * 0.2))
            
        enemies.append([
            random.randint(50, WIDTH - 50),
            random.randint(-300, -50),
            speed, max_hp, max_hp, bot_color, bot_type
        ])

# --- SYSTEM FONTS ---
font_title = pygame.font.SysFont("Courier", 42, bold=True)
font_medium = pygame.font.SysFont("Courier", 22, bold=True)
font_small = pygame.font.SysFont("Courier", 14)

# --- MAIN ASYNC LOOP INTERFACE ---
async def main():
    global game_state, current_level, score, menu_angle, player_x, player_y, selected_ship, bullets, enemies
    
    while True:
        screen.fill(BG_COLOR)
        
        # 1. Starfield Background Loop
        for star in stars:
            if game_state == "PLAYING":
                star["y"] += star["speed"]
                if star["y"] > HEIGHT:
                    star["y"] = 0
                    star["x"] = random.randint(0, WIDTH)
            pygame.draw.circle(screen, (140, 140, 190), (int(star["x"]), int(star["y"])), star["size"])

        # 2. KEYBOARD CONTROL MONITOR
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                
            if event.type == pygame.KEYDOWN:
                if game_state == "MENU":
                    if event.key == pygame.K_LEFT:
                        selected_ship = (selected_ship - 1 + 3) % 3
                    elif event.key == pygame.K_RIGHT:
                        selected_ship = (selected_ship + 1) % 3
                    elif event.key == pygame.K_RETURN:
                        score = 0
                        current_level = 1
                        player_x, player_y = 400, 500
                        bullets.clear()
                        spawn_enemies()
                        game_state = "PLAYING"
                elif game_state == "PLAYING":
                    if event.key == pygame.K_SPACE:
                        fire_laser()
                elif game_state == "GAME_OVER":
                    if event.key == pygame.K_RETURN:
                        game_state = "MENU"

        keys = pygame.key.get_pressed()
        if game_state == "PLAYING":
            if keys[pygame.K_LEFT] and player_x > 50: player_x -= player_speed
            if keys[pygame.K_RIGHT] and player_x < WIDTH - 50: player_x += player_speed
            if keys[pygame.K_UP] and player_y > 50: player_y -= player_speed
            if keys[pygame.K_DOWN] and player_y < HEIGHT - 30: player_y += player_speed

        # 3. GAMEPLAY ENGINE RULES
        if game_state == "MENU":
            menu_angle = (menu_angle + 2) % 360
            draw_3d_wireframe_ship(menu_angle, ships[selected_ship])
            
            txt_title = font_title.render("HYPER-DRIVE 1995", True, GLOW_GREEN)
            txt_select = font_small.render("< USE LEFT / RIGHT ARROWS TO CHOOSE HANGAR SHIP >", True, WHITE)
            txt_ship = font_medium.render(f"VESSEL: {ships[selected_ship]['name']}", True, ships[selected_ship]["color"])
            txt_wep = font_small.render(f"SYSTEMS: {ships[selected_ship]['shot']} LASER SYSTEM", True, WHITE)
            txt_desc = font_small.render(ships[selected_ship]["desc"], True, (160, 160, 160))
            txt_launch = font_medium.render("PRESS [ENTER] TO LAUNCH MISSION", True, GLOW_YELLOW)
            
            screen.blit(txt_title, (WIDTH // 2 - txt_title.get_width() // 2, 40))
            screen.blit(txt_select, (WIDTH // 2 - txt_select.get_width() // 2, 370))
            screen.blit(txt_ship, (WIDTH // 2 - txt_ship.get_width() // 2, 410))
            screen.blit(txt_wep, (WIDTH // 2 - txt_wep.get_width() // 2, 445))
            screen.blit(txt_desc, (WIDTH // 2 - txt_desc.get_width() // 2, 475))
            screen.blit(txt_launch, (WIDTH // 2 - txt_launch.get_width() // 2, 530))

        elif game_state == "PLAYING":
            lbl_score = font_medium.render(f"SCORE: {score}", True, GLOW_GREEN)
            lbl_level = font_medium.render(f"WAVE: {current_level}", True, GLOW_YELLOW)
            screen.blit(lbl_score, (20, 20))
            screen.blit(lbl_level, (WIDTH - lbl_level.get_width() - 20, 20))
            
            ship_color = ships[selected_ship]["color"]
            p1 = (player_x, player_y - 18)
            p2 = (player_x - 16, player_y + 16)
            p3 = (player_x + 16, player_y + 16)
            pygame.draw.polygon(screen, ship_color, [p1, p2, p3])
            pygame.draw.polygon(screen, WHITE, [p1, p2, p3], 2)
            pygame.draw.rect(screen, (255, 100, 0), (player_x - 4, player_y + 16, 8, 8))

            if ships[selected_ship]["drones"]:
                pygame.draw.circle(screen, WHITE, (int(player_x - 35), int(player_y + 5)), 6)
                pygame.draw.circle(screen, GLOW_YELLOW, (int(player_x - 35), int(player_y + 5)), 3)
                pygame.draw.circle(screen, WHITE, (int(player_x + 35), int(player_y + 5)), 6)
                pygame.draw.circle(screen, GLOW_YELLOW, (int(player_x + 35), int(player_y + 5)), 3)

            for b in bullets[:]:
                b[0] += b[2]
                b[1] += b[3]
                pygame.draw.circle(screen, LASER_BLUE, (int(b[0]), int(b[1])), 5)
                pygame.draw.circle(screen, WHITE, (int(b[0]), int(b[1])), 2)
                if b[1] < 0 or b[1] > HEIGHT or b[0] < 0 or b[0] > WIDTH:
                    bullets.remove(b)

            for e in enemies[:]:
                bot_type = e[6]
                
                if bot_type == "STALKER":
                    if e[0] < player_x: e[0] += e[2] * 0.6
                    elif e[0] > player_x: e[0] -= e[2] * 0.6
                    e[1] += e[2] * 0.8  
                else:
                    e[1] += e[2]
                
                if bot_type == "STALKER":
                    top = (e[0], e[1] - 15)
                    right = (e[0] + 15, e[1])
                    bottom = (e[0], e[1] + 15)
                    left = (e[0] - 15, e[1])
                    pygame.draw.polygon(screen, e[5], [top, right, bottom, left])
                    pygame.draw.polygon(screen, WHITE, [top, right, bottom, left], 2)
                    pygame.draw.circle(screen, WHITE, (int(e[0]), int(e[1])), 3) 
                else:
                    pygame.draw.rect(screen, e[5], (int(e[0] - 15), int(e[1] - 15), 30, 30))
                    pygame.draw.rect(screen, WHITE, (int(e[0] - 15), int(e[1] - 15), 30, 30), 2)
                    pygame.draw.rect(screen, BG_COLOR, (int(e[0] - 6), int(e[1] - 6), 12, 6))

                hp_percent = e[3] / e[4]
                pygame.draw.line(screen, (255, 0, 0), (int(e[0] - 15), int(e[1] - 22)), (int(e[0] + 15), int(e[1] - 22)), 2)
                pygame.draw.line(screen, (0, 255, 0), (int(e[0] - 15), int(e[1] - 22)), (int(e[0] - 15 + (30 * hp_percent)), int(e[1] - 22)), 2)

                if e[1] > HEIGHT + 20:
                    e[1] = random.randint(-100, -40)
                    e[0] = random.randint(50, WIDTH - 50)

                if math.hypot(player_x - e[0], player_y - e[1]) < 28:
                    game_state = "GAME_OVER"

                for b in bullets[:]:
                    if math.hypot(b[0] - e[0], b[1] - e[1]) < 22:
                        if b in bullets: bullets.remove(b)
                        e[3] -= 1
                        if e[3] <= 0:
                            if e in enemies: enemies.remove(e)
                            score += 250 if bot_type == "STALKER" else 150
                        break

            if len(enemies) == 0:
                current_level += 1
                spawn_enemies()

        elif game_state == "GAME_OVER":
            over_txt = font_title.render("MISSION FAILED", True, (255, 50, 50))
            stat_txt = font_medium.render(f"FINAL SCORE: {score}", True, WHITE)
            restart_txt = font_small.render("PRESS [ENTER] TO RE-ENTER RETRO HANGAR", True, GLOW_YELLOW)
            
            screen.blit(over_txt, (WIDTH // 2 - over_txt.get_width() // 2, 200))
            screen.blit(stat_txt, (WIDTH // 2 - stat_txt.get_width() // 2, 280))
            screen.blit(restart_txt, (WIDTH // 2 - restart_txt.get_width() // 2, 380))

        pygame.display.flip()
        clock.tick(60)
        
        # This keeps the web page alive and stops it from lagging out
        await asyncio.sleep(0)

# Start engine execution
asyncio.run(main())